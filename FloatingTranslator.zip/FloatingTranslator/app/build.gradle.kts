plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.floatingtranslator"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.floatingtranslator"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:text-recognition-japanese:16.0.1")
    implementation("com.google.mlkit:text-recognition-korean:16.0.1")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
    implementation("com.google.mlkit:text-recognition-devanagari:16.0.1")
    implementation("com.google.android.gms:play-services-ads:23.3.0")
    // قراءة النص العربي من الشاشة (ML Kit مش بيدعم العربي، فبنستخدم Tesseract بس للعربي)
    implementation("cz.adaptech.tesseract4android:tesseract4android:4.9.0")
}
