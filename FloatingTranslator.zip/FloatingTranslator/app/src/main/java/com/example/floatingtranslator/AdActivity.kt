package com.example.floatingtranslator

import android.os.Bundle
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd

// نشاط شفاف صغير مهمته الوحيدة إنه يعرض إعلان كامل الشاشة ثم يقفل نفسه.
// بيتفتح إما لما يبدأ المستخدم استخدام الترجمة العائمة، أو كل نص ساعة وهو شغال.
class AdActivity : android.app.Activity() {

    // معرّف الإعلان الحقيقي بتاع حسابك على AdMob (نوعه: إعلان فتح التطبيق)
    private val AD_UNIT_ID = "ca-app-pub-2619370025617182/4838655407"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this)
        AppOpenAd.load(this, AD_UNIT_ID, AdRequest.Builder().build(),
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() { finish() }
                        override fun onAdFailedToShowFullScreenContent(e: AdError) { finish() }
                    }
                    ad.show(this@AdActivity)
                }
                override fun onAdFailedToLoad(e: LoadAdError) {
                    // مفيش إعلان متاح دلوقتي، اقفل من غير ما توقف المستخدم
                    finish()
                }
            })
    }
}
