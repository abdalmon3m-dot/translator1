package com.example.floatingtranslator

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private val REQ_CAPTURE = 100
    private val langs = listOf("ja" to "اليابانية", "ko" to "الكورية", "en" to "الإنجليزية", "zh" to "الصينية")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun tv(text: String, size: Float) = TextView(this).apply {
            this.text = text; textSize = size; gravity = Gravity.START
            setPadding(0, pad / 2, 0, pad / 2)
        }
        root.addView(tv("المترجم العائم", 26f))
        root.addView(tv("ترجمة نصوص الشاشة إلى العربية بلمسة واحدة فوق أي تطبيق.", 15f))
        root.addView(tv("لغة النص الأصلي:", 16f))

        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, langs.map { it.second })
        val prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)
        spinner.setSelection(langs.indexOfFirst { it.first == prefs.getString("src", "ja") }.coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putString("src", langs[pos].first).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(spinner)

        val start = Button(this).apply { text = "ابدأ الترجمة العائمة"; setOnClickListener { begin() } }
        val stop = Button(this).apply {
            text = "إيقاف"
            setOnClickListener {
                startService(Intent(this@MainActivity, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            }
        }
        root.addView(start); root.addView(stop)
        root.addView(tv("ملاحظة: أول استخدام يحتاج إنترنت لتنزيل نموذج الترجمة (مرة واحدة).", 13f))
        setContentView(root)
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن العرض فوق التطبيقات ثم ارجع", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java).apply {
                action = OverlayService.ACTION_START
                putExtra("code", resultCode)
                putExtra("data", data)
                putExtra("src", getSharedPreferences("prefs", Context.MODE_PRIVATE).getString("src", "ja"))
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            Toast.makeText(this, "ظهر الزر العائم، افتح أي تطبيق واضغطه", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }
}
