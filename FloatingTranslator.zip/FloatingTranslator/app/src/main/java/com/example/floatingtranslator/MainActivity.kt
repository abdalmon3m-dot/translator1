package com.example.floatingtranslator

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private val REQ_CAPTURE = 100
    private val langs = listOf("ja" to "اليابانية", "ko" to "الكورية", "en" to "الإنجليزية", "zh" to "الصينية")

    // لوحة ألوان بسيطة ومتناسقة
    private val bgColor = Color.parseColor("#0F172A")
    private val cardColor = Color.parseColor("#1E293B")
    private val accent = Color.parseColor("#3B82F6")
    private val accentDark = Color.parseColor("#2563EB")
    private val danger = Color.parseColor("#EF4444")
    private val textPrimary = Color.parseColor("#F8FAFC")
    private val textSecondary = Color.parseColor("#94A3B8")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 16): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this).apply { setBackgroundColor(bgColor) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(40), dp(24), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        // ------- الشعار والعنوان -------
        val logo = TextView(this).apply {
            text = "🌐"
            textSize = 48f
            gravity = Gravity.CENTER
        }
        root.addView(logo, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(8) })

        val title = TextView(this).apply {
            text = "المترجم العائم"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textPrimary)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(6) })

        val subtitle = TextView(this).apply {
            text = "ترجمة أي نص على الشاشة إلى العربية بلمسة واحدة، فوق أي تطبيق آخر"
            textSize = 14f
            setTextColor(textSecondary)
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(28) })

        // ------- بطاقة اختيار اللغة -------
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardColor, 18)
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        val langLabel = TextView(this).apply {
            text = "لغة النص الأصلي"
            textSize = 14f
            setTextColor(textSecondary)
        }
        card.addView(langLabel, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(8) })

        val spinner = Spinner(this).apply {
            background = rounded(bgColor, 12)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val adapter = object : ArrayAdapter<String>(
            this, android.R.layout.simple_spinner_dropdown_item, langs.map { it.second }
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.setTextColor(textPrimary); v.textSize = 16f
                v.setPadding(dp(4), dp(10), dp(4), dp(10))
                return v
            }
        }
        spinner.adapter = adapter
        val prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)
        spinner.setSelection(langs.indexOfFirst { it.first == prefs.getString("src", "ja") }.coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putString("src", langs[pos].first).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        card.addView(spinner)
        root.addView(card, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(20) })

        // ------- زر البدء -------
        val start = Button(this).apply {
            text = "▶  ابدأ الترجمة العائمة"
            textSize = 16f
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = rounded(accent, 14)
            setPadding(0, dp(16), 0, dp(16))
            setOnClickListener { begin() }
        }
        root.addView(start, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) })

        // ------- زر الإيقاف -------
        val stop = Button(this).apply {
            text = "⏹  إيقاف التطبيق"
            textSize = 15f
            setTextColor(danger)
            isAllCaps = false
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), danger)
            }
            setPadding(0, dp(14), 0, dp(14))
            setOnClickListener {
                startService(Intent(this@MainActivity, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            }
        }
        root.addView(stop, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(24) })

        // ------- تلميحات الاستخدام -------
        val tipsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardColor, 18)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        fun tip(icon: String, text: String) {
            val row = TextView(this).apply {
                this.text = "$icon   $text"
                textSize = 13f
                setTextColor(textSecondary)
                setPadding(0, dp(4), 0, dp(4))
            }
            tipsCard.addView(row)
        }
        tip("👆", "اضغط الزر العائم مرة واحدة لترجمة الشاشة، واضغط تاني لإخفائها")
        tip("✋", "اضغط مطوّلاً على الزر العائم لإظهار علامة ✕ تقفل التطبيق")
        tip("🌐", "يحتاج التطبيق اتصال إنترنت دائم لجودة ترجمة أفضل")
        root.addView(tipsCard, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        scroll.addView(root)
        setContentView(scroll)
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن العرض فوق التطبيقات ثم ارجع", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java).apply {
                action = OverlayService.ACTION_START
                putExtra("code", resultCode)
                putExtra("data", data)
                putExtra("src", getSharedPreferences("prefs", Context.MODE_PRIVATE).getString("src", "ja"))
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            Toast.makeText(this, "ظهر الزر العائم، افتح أي تطبيق واضغطه", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }
}
