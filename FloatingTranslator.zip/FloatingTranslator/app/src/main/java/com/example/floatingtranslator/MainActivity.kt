package com.example.floatingtranslator

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd

class MainActivity : Activity() {

    private val REQ_CAPTURE = 100

    // معرّفات الإعلانات الحقيقية بتاعة حسابك على AdMob
    private val BANNER_AD_ID = "ca-app-pub-2619370025617182/5865805770"
    private val INTERSTITIAL_AD_ID = "ca-app-pub-2619370025617182/4838655407"
    private var pendingOpenAd: AppOpenAd? = null

    // لوحة ألوان بسيطة ومتناسقة
    private val bgColor = Color.parseColor("#0F172A")
    private val cardColor = Color.parseColor("#1E293B")
    private val accent = Color.parseColor("#3B82F6")
    private val accentDark = Color.parseColor("#2563EB")
    private val danger = Color.parseColor("#EF4444")
    private val textPrimary = Color.parseColor("#F8FAFC")
    private val textSecondary = Color.parseColor("#94A3B8")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 16): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this)
        preloadInterstitial()

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgColor)
        }

        // ------- بانر إعلاني فوق -------
        val topBanner = AdView(this).apply {
            setAdSize(AdSize.BANNER)
            adUnitId = BANNER_AD_ID
            loadAd(AdRequest.Builder().build())
        }
        outer.addView(topBanner, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.CENTER_HORIZONTAL })

        val scroll = ScrollView(this).apply { setBackgroundColor(bgColor) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(24), dp(24), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        // ------- الشعار والعنوان -------
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher_foreground)
            setColorFilter(accent)
        }
        root.addView(logo, LinearLayout.LayoutParams(dp(56), dp(56)).apply {
            gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(8)
        })

        val title = TextView(this).apply {
            text = "المترجم العائم"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textPrimary)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(6) })

        val subtitle = TextView(this).apply {
            text = "ترجمة أي نص على الشاشة بلمسة واحدة، فوق أي تطبيق آخر، من أي لغة لأي لغة"
            textSize = 14f
            setTextColor(textSecondary)
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(28) })

        // ------- زر البدء -------
        val start = Button(this).apply {
            text = "  ابدأ الترجمة العائمة"
            textSize = 16f
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = rounded(accent, 14)
            setPadding(0, dp(16), 0, dp(16))
            setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_play, 0, 0, 0)
            compoundDrawablePadding = dp(8)
            gravity = Gravity.CENTER
            setOnClickListener { begin() }
        }
        root.addView(start, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) })

        // ------- زر الإيقاف -------
        val stop = Button(this).apply {
            text = "  إيقاف التطبيق"
            textSize = 15f
            setTextColor(danger)
            isAllCaps = false
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), danger)
            }
            setPadding(0, dp(14), 0, dp(14))
            setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_stop, 0, 0, 0)
            compoundDrawablePadding = dp(8)
            gravity = Gravity.CENTER
            setOnClickListener {
                startService(Intent(this@MainActivity, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            }
        }
        root.addView(stop, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(24) })

        // ------- تلميحات الاستخدام -------
        val tipsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardColor, 18)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        fun tip(dotColor: Int, text: String) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(5), 0, dp(5))
            }
            val dot = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(dotColor) }
            }
            row.addView(dot, LinearLayout.LayoutParams(dp(7), dp(7)).apply { marginStart = dp(2); marginEnd = dp(10) })
            row.addView(TextView(this).apply {
                this.text = text; textSize = 13f; setTextColor(textSecondary)
            })
            tipsCard.addView(row)
        }
        tip(accent, "اضغط الزر العائم وهيترجم فوراً بآخر لغة مختارة")
        tip(accent, "ادّي الزر تاني وهتختفي الترجمة، وجرّب الشارة الصغيرة جنب الزر لتغيير اللغة")
        tip(danger, "اضغط مطوّلاً على الزر العائم لإظهار علامة ✕ تقفل التطبيق")
        tip(textSecondary, "يحتاج التطبيق اتصال إنترنت دائم لأنه يترجم عبر خدمة جوجل السحابية")
        root.addView(tipsCard, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        scroll.addView(root)
        outer.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        // ------- بانر إعلاني تحت -------
        val bottomBanner = AdView(this).apply {
            setAdSize(AdSize.BANNER)
            adUnitId = BANNER_AD_ID
            loadAd(AdRequest.Builder().build())
        }
        outer.addView(bottomBanner, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.CENTER_HORIZONTAL })

        setContentView(outer)
    }

    private fun preloadInterstitial() {
        AppOpenAd.load(this, INTERSTITIAL_AD_ID, AdRequest.Builder().build(),
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) { pendingOpenAd = ad }
                override fun onAdFailedToLoad(e: LoadAdError) { pendingOpenAd = null }
            })
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن العرض فوق التطبيقات ثم ارجع", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        // اعرض إعلان كامل الشاشة أول ما المستخدم يفعّل الميزة، ثم كمّل بعد ما يقفله
        val ad = pendingOpenAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() { pendingOpenAd = null; preloadInterstitial(); proceedStart() }
                override fun onAdFailedToShowFullScreenContent(e: AdError) { pendingOpenAd = null; proceedStart() }
            }
            ad.show(this)
        } else {
            proceedStart()
        }
    }

    private fun proceedStart() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java).apply {
                action = OverlayService.ACTION_START
                putExtra("code", resultCode)
                putExtra("data", data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            Toast.makeText(this, "ظهر الزر العائم، افتح أي تطبيق واضغطه", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }
}
