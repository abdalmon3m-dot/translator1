package com.example.floatingtranslator

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        private const val CHANNEL = "translator"
    }

    // كل اللغات المدعومة. ocr=true تعني إن الشاشة تقدر تُقرأ بيها كلغة مصدر
    data class Lang(val code: String, val name: String, val ocr: Boolean)
    private val ALL_LANGS = listOf(
        Lang("en", "الإنجليزية", true),
        Lang("ar", "العربية", true), // عبر Tesseract (ML Kit مش بيدعم العربي)
        Lang("ja", "اليابانية", true),
        Lang("ko", "الكورية", true),
        Lang("zh-CN", "الصينية", true),
        Lang("fr", "الفرنسية", true),
        Lang("de", "الألمانية", true),
        Lang("es", "الإسبانية", true),
        Lang("it", "الإيطالية", true),
        Lang("pt", "البرتغالية", true),
        Lang("tr", "التركية", true),
        Lang("id", "الإندونيسية", true),
        Lang("vi", "الفيتنامية", true),
        Lang("hi", "الهندية", true),
        Lang("ru", "الروسية", false),
        Lang("fa", "الفارسية", false),
        Lang("ur", "الأردية", false)
    )
    private fun srcLangs() = ALL_LANGS.filter { it.ocr }
    private val rtlCodes = setOf("ar", "fa", "ur", "he")

    private val handler = Handler(Looper.getMainLooper())
    // تنفيذ طلبات الترجمة على مجموعة Threads محدودة يُعاد استخدامها، بدل إنشاء Thread جديد لكل طلب
    private val netExecutor: ExecutorService = Executors.newFixedThreadPool(3)

    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var latest: Image? = null
    private val lock = Any()
    private var sw = 0
    private var sh = 0

    private var button: TextView? = null
    private var buttonParams: WindowManager.LayoutParams? = null
    private var langBadge: TextView? = null
    private var langBadgeParams: WindowManager.LayoutParams? = null
    private var overlay: TranslationOverlayView? = null
    private var chooser: View? = null
    private var busy = false

    private var currentSrc = "en"
    private var currentTgt = "ar"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (intent?.action == ACTION_START && projection == null) {
            startInForeground()
            val code = intent.getIntExtra("code", Activity.RESULT_CANCELED)
            @Suppress("DEPRECATION")
            val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
            val prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)
            currentSrc = prefs.getString("lastSrc", "en") ?: "en"
            currentTgt = prefs.getString("lastTgt", "ar") ?: "ar"
            setupCapture(code, data)
            addButton()
            startPeriodicAds()
        }
        return START_NOT_STICKY
    }

    // ---------- إعلان دوري كل نص ساعة وهو شغال ----------
    private val periodicAdRunnable = object : Runnable {
        override fun run() {
            try {
                val i = Intent(this@OverlayService, AdActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (_: Exception) {}
            handler.postDelayed(this, 30 * 60 * 1000L)
        }
    }
    private fun startPeriodicAds() {
        handler.postDelayed(periodicAdRunnable, 30 * 60 * 1000L)
    }

    // ---------- foreground ----------
    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "المترجم العائم", NotificationManager.IMPORTANCE_LOW))
        }
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        val n = b.setContentTitle("المترجم العائم يعمل")
            .setContentText("اضغط الزر العائم لترجمة الشاشة")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(Notification.Action.Builder(null, "إيقاف", stop).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------- OCR: ML Kit ----------
    private fun buildRecognizer(src: String): TextRecognizer = when (src) {
        "ja" -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        "ko" -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        "zh-CN" -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        "hi" -> TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) // لاتيني
    }

    // تحويل نتيجة ML Kit لتمثيل موحّد (OcrLine) نفس شكل بيانات Tesseract،
    // عشان نظام التجميع البصري يشتغل بنفس الطريقة أياً كان محرك القراءة
    private fun flattenMlKit(result: Text): List<OcrLine> {
        val lines = mutableListOf<OcrLine>()
        for (block in result.textBlocks) {
            for (line in block.lines) {
                val r = line.boundingBox ?: continue
                if (line.text.isBlank()) continue
                lines.add(OcrLine(r, line.text.trim()))
            }
        }
        return lines
    }

    // ---------- تجميع بصري ذكي: يحوّل أسطر النص المنفردة لمجموعات (Blocks) بناءً على
    // القرب الرأسي، التداخل الأفقي (المحاذاة)، وتقارب حجم الخط — بدل معاملة كل سطر لوحده
    // أو تجميع الشاشة كلها في كتلة واحدة ---------
    private fun buildVisualBlocks(lines: List<OcrLine>): List<Pair<Rect, String>> {
        if (lines.isEmpty()) return emptyList()
        data class Cluster(var rect: Rect, val items: MutableList<OcrLine>)
        val clusters = mutableListOf<Cluster>()

        for (line in lines.sortedWith(compareBy({ it.rect.top }, { it.rect.left }))) {
            val last = clusters.lastOrNull()
            val shouldMerge = if (last != null) {
                val lastLine = last.items.last()
                val avgH = ((lastLine.rect.height() + line.rect.height()) / 2).coerceAtLeast(1)
                val vGap = line.rect.top - lastLine.rect.bottom
                val overlapLeft = maxOf(line.rect.left, lastLine.rect.left)
                val overlapRight = minOf(line.rect.right, lastLine.rect.right)
                val overlapW = (overlapRight - overlapLeft).coerceAtLeast(0)
                val minW = minOf(line.rect.width(), lastLine.rect.width()).coerceAtLeast(1)
                val overlapRatio = overlapW.toFloat() / minW
                val sizeRatio = maxOf(line.rect.height(), lastLine.rect.height()).toFloat() /
                        minOf(line.rect.height(), lastLine.rect.height()).coerceAtLeast(1)
                vGap < avgH * 0.9 && overlapRatio > 0.25f && sizeRatio < 1.7f
            } else false

            if (shouldMerge && last != null) {
                last.items.add(line)
                last.rect = Rect(last.rect).apply { union(line.rect) }
            } else {
                clusters.add(Cluster(Rect(line.rect), mutableListOf(line)))
            }
        }
        return clusters.map { c -> c.rect to c.items.joinToString("\n") { it.text } }
    }

    // ---------- ترجمة عبر خدمة جوجل السحابية ----------
    private fun translateText(text: String, src: String, tgt: String, cb: (String) -> Unit) {
        netExecutor.execute {
            val result = try {
                val q = URLEncoder.encode(text, "UTF-8")
                val urlStr = "https://translate.googleapis.com/translate_a/single" +
                        "?client=gtx&sl=$src&tl=$tgt&dt=t&q=$q"
                val conn = URL(urlStr).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                // مطلوب User-Agent وإلا خدمة جوجل بترفض الطلب بهدوء وترجع خطأ يظهر كأنه بدون ترجمة
                conn.setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0 Safari/537.36"
                )
                if (conn.responseCode != 200) throw Exception("HTTP ${conn.responseCode}")
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                parseGoogleTranslate(body)
            } catch (e: Exception) {
                null
            }
            handler.post { cb(result ?: text) }
        }
    }

    private fun parseGoogleTranslate(json: String): String {
        val root = JSONArray(json)
        val segments = root.getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until segments.length()) {
            val seg = segments.getJSONArray(i)
            sb.append(seg.getString(0))
        }
        return sb.toString()
    }

    // ---------- capture ----------
    private fun setupCapture(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { handler.post { stopSelf() } }
        }, handler)

        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds; sw = b.width(); sh = b.height()
        } else {
            val m = android.util.DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m); sw = m.widthPixels; sh = m.heightPixels
        }
        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 3)
        reader!!.setOnImageAvailableListener({ r ->
            val img = try { r.acquireLatestImage() } catch (e: Exception) { null } ?: return@setOnImageAvailableListener
            synchronized(lock) { latest?.close(); latest = img }
        }, handler)
        vDisplay = projection!!.createVirtualDisplay(
            "capture", sw, sh, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler
        )
    }

    private fun grabBitmap(): Bitmap? = synchronized(lock) {
        try {
            val img = latest ?: return null
            val plane = img.planes[0]
            val rowPadding = plane.rowStride - plane.pixelStride * img.width
            val full = Bitmap.createBitmap(img.width + rowPadding / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            val out = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
            if (out !== full) full.recycle()
            out
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    // ---------- الزر العائم ----------
    private fun addButton() {
        val d = resources.displayMetrics.density
        val size = (52 * d).toInt()
        val btn = TextView(this).apply {
            text = "ت"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#E61E88E5"))
            }
        }
        val p = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = sh / 3 }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        var longPressed = false
        val longPressRunnable = Runnable {
            longPressed = true
            showCloseMark()
        }
        btn.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false; longPressed = false
                    handler.postDelayed(longPressRunnable, 500)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                        moved = true
                        handler.removeCallbacks(longPressRunnable)
                    }
                    if (moved) {
                        p.x = ox + dx; p.y = oy + dy
                        wm.updateViewLayout(btn, p)
                        updateBadgePosition()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPressRunnable)
                    if (!moved && !longPressed) onButtonClick()
                }
            }
            true
        }
        button = btn; buttonParams = p
        wm.addView(btn, p)
        addLangBadge()
    }

    // شارة صغيرة جنب الزر بتوضح لغة الهدف الحالية، ولو ضغطت عليها بتفتح اختيار اللغة
    private fun addLangBadge() {
        val d = resources.displayMetrics.density
        val size = (26 * d).toInt()
        val bp = buttonParams ?: return
        val badge = TextView(this).apply {
            text = badgeText()
            textSize = 9f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#1E293B"))
                setStroke((1.5f * d).toInt(), Color.WHITE)
            }
            setOnClickListener { showLanguageChooser() }
        }
        val p = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = bp.x + bp.width - (size / 2)
            y = bp.y + bp.height - (size / 2)
        }
        langBadge = badge; langBadgeParams = p
        wm.addView(badge, p)
    }

    private fun badgeText(): String = currentTgt.take(2).uppercase()

    private fun updateBadgePosition() {
        val bp = buttonParams ?: return
        val p = langBadgeParams ?: return
        val b = langBadge ?: return
        val size = p.width
        p.x = bp.x + bp.width - (size / 2)
        p.y = bp.y + bp.height - (size / 2)
        try { wm.updateViewLayout(b, p) } catch (_: Exception) {}
    }

    private fun refreshBadgeText() {
        langBadge?.text = badgeText()
    }

    // زر إلغاء ✕ يظهر عند الضغط المطول على الزر العائم، ويغلق التطبيق بالكامل
    private var closeMark: TextView? = null
    private fun showCloseMark() {
        if (closeMark != null) return
        val d = resources.displayMetrics.density
        val size = (56 * d).toInt()
        val mark = TextView(this).apply {
            text = "✕"; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#EF4444"))
            }
        }
        val bp = buttonParams!!
        val p = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = bp.x
            y = (bp.y - size - (10 * d)).toInt().coerceAtLeast(0)
        }
        mark.setOnClickListener {
            handler.removeCallbacksAndMessages(null)
            stopSelf()
        }
        closeMark = mark
        wm.addView(mark, p)
        toast("اضغط على ✕ لإغلاق التطبيق")
        handler.postDelayed({ hideCloseMark() }, 4000)
    }

    private fun hideCloseMark() {
        closeMark?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        closeMark = null
    }

    private fun onButtonClick() {
        if (overlay != null) { dismissOverlay(); return }
        if (busy) return
        // يترجم فوراً بآخر لغة محفوظة، من غير ما يسأل في كل مرة (تغيير اللغة من الشارة الصغيرة)
        busy = true
        button?.visibility = View.INVISIBLE
        handler.postDelayed({ startTranslation(currentSrc, currentTgt) }, 150)
    }

    // ---------- اختيار لغة المصدر والهدف ----------
    private fun langChip(lang: Lang, selectedCode: () -> String, onPick: (String) -> Unit): TextView {
        val d = resources.displayMetrics.density
        fun refreshStyle(v: TextView) {
            val isSel = selectedCode() == lang.code
            v.background = GradientDrawable().apply {
                cornerRadius = 20 * d
                setColor(if (isSel) Color.parseColor("#3B82F6") else Color.parseColor("#334155"))
            }
            v.setTextColor(if (isSel) Color.WHITE else Color.parseColor("#CBD5E1"))
        }
        return TextView(this).apply {
            text = lang.name
            textSize = 13f
            setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            refreshStyle(this)
            setOnClickListener {
                onPick(lang.code)
                (parent as? LinearLayout)?.let { row ->
                    for (i in 0 until row.childCount) refreshStyle(row.getChildAt(i) as TextView)
                }
            }
        }
    }

    private fun chipsRow(langs: List<Lang>, selectedCode: () -> String, onPick: (String) -> Unit): HorizontalScrollView {
        val d = resources.displayMetrics.density
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        langs.forEach { lang ->
            val chip = langChip(lang, selectedCode, onPick)
            row.addView(chip, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = (8 * d).toInt() })
        }
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
        }
    }

    private fun showLanguageChooser() {
        if (chooser != null) return
        val d = resources.displayMetrics.density

        var selSrc = if (srcLangs().any { it.code == currentSrc }) currentSrc else "en"
        var selTgt = currentTgt

        val dim = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#99000000"))
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = 20 * d
                setColor(Color.parseColor("#1E293B"))
            }
            setPadding((20 * d).toInt(), (20 * d).toInt(), (20 * d).toInt(), (20 * d).toInt())
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        fun label(t: String) = TextView(this).apply {
            text = t; textSize = 14f; setTextColor(Color.parseColor("#94A3B8"))
            setPadding(0, (10 * d).toInt(), 0, (6 * d).toInt())
        }

        card.addView(TextView(this).apply {
            text = "اختر لغة الترجمة"; textSize = 17f; setTextColor(Color.WHITE)
            setPadding(0, 0, 0, (4 * d).toInt())
        })

        card.addView(label("من لغة:"))
        val srcRow = chipsRow(srcLangs(), { selSrc }) { selSrc = it }
        card.addView(srcRow)

        card.addView(label("إلى لغة:"))
        val tgtRow = chipsRow(ALL_LANGS, { selTgt }) { selTgt = it }
        card.addView(tgtRow)

        val goBtn = TextView(this).apply {
            text = "احفظ واترجم الآن"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                cornerRadius = 14 * d
                setColor(Color.parseColor("#2563EB"))
            }
            setPadding(0, (14 * d).toInt(), 0, (14 * d).toInt())
            setOnClickListener {
                currentSrc = selSrc; currentTgt = selTgt
                getSharedPreferences("prefs", Context.MODE_PRIVATE).edit()
                    .putString("lastSrc", selSrc).putString("lastTgt", selTgt).apply()
                refreshBadgeText()
                hideChooser()
                busy = true
                button?.visibility = View.INVISIBLE
                handler.postDelayed({ startTranslation(selSrc, selTgt) }, 200)
            }
        }
        card.addView(goBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = (16 * d).toInt() })

        val cancelBtn = TextView(this).apply {
            text = "إلغاء"
            textSize = 13f
            setTextColor(Color.parseColor("#94A3B8"))
            gravity = Gravity.CENTER
            setPadding(0, (12 * d).toInt(), 0, 0)
            setOnClickListener { hideChooser() }
        }
        card.addView(cancelBtn)

        dim.addView(card, FrameLayout.LayoutParams(
            (320 * d).toInt(), FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.CENTER })
        dim.setOnClickListener { hideChooser() }

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        chooser = dim
        wm.addView(dim, p)
    }

    private fun hideChooser() {
        chooser?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        chooser = null
    }

    // ---------- pipeline ----------
    private fun startTranslation(src: String, tgt: String) {
        val bmp = grabBitmap()
        if (bmp == null) { fail("تعذر التقاط الشاشة"); return }

        if (src == "ar") {
            // Tesseract متزامن (Blocking) فلازم يتنفذ في Thread خلفي
            netExecutor.execute {
                val lines = try { TesseractOcr.extractLines(this, bmp) } catch (e: Exception) { emptyList() }
                handler.post { onLinesReady(lines, bmp, src, tgt, recognizer = null) }
            }
        } else {
            val recognizer = buildRecognizer(src)
            recognizer.process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { result ->
                    onLinesReady(flattenMlKit(result), bmp, src, tgt, recognizer)
                }
                .addOnFailureListener {
                    recognizer.close()
                    fail("فشل التعرف على النص")
                    bmp.recycle()
                }
        }
    }

    // فاصل نادر الحدوث في النصوص العادية عشان نقدر نفصل الترجمات بعد ما نترجمها مع بعض بالسياق الكامل
    private val SEP = "\n§§§\n"

    private fun onLinesReady(lines: List<OcrLine>, bmp: Bitmap, src: String, tgt: String, recognizer: TextRecognizer?) {
        val blocks = buildVisualBlocks(lines)
        if (blocks.isEmpty()) {
            fail("لم يتم العثور على نص")
            recognizer?.close()
            bmp.recycle()
            return
        }

        val texts = blocks.map { it.second }
        val combined = texts.joinToString(SEP)

        // لو النص كله كبير جداً، الترجمة المجمّعة ممكن تفشل بسبب طول الرابط، فنترجم كل جملة لوحدها مباشرة
        if (combined.length > 1200) {
            translateEachSeparately(blocks, texts, src, tgt, bmp, recognizer)
            return
        }

        // ترجمة كل النصوص مرة واحدة مع بعض، عشان المحرك يفهم السياق العام بينها
        translateText(combined, src, tgt) { joinedResult ->
            val parts = joinedResult.split(SEP.trim()).map { it.trim().trim('\n') }
            if (parts.size == blocks.size) {
                finishBlocks(blocks, parts, bmp, tgt, recognizer)
            } else {
                // فشل الفصل (المحرك غيّر شكل الفاصل)، نترجم كل جملة لوحدها كحل احتياطي
                translateEachSeparately(blocks, texts, src, tgt, bmp, recognizer)
            }
        }
    }

    private fun finishBlocks(
        blocks: List<Pair<Rect, String>>,
        translations: List<String>,
        bmp: Bitmap, tgt: String, recognizer: TextRecognizer?
    ) {
        val items = blocks.mapIndexed { i, (rect, _) ->
            val (bg, complex) = sampleBackground(bmp, rect)
            TranslationOverlayView.Item(rect, translations[i], bg, contrast(bg), complex)
        }
        showOverlay(items, tgt in rtlCodes)
        recognizer?.close()
        bmp.recycle()
    }

    private fun translateEachSeparately(
        blocks: List<Pair<Rect, String>>,
        texts: List<String>, src: String, tgt: String,
        bmp: Bitmap, recognizer: TextRecognizer?
    ) {
        val items = arrayOfNulls<TranslationOverlayView.Item>(blocks.size)
        var pending = blocks.size
        blocks.forEachIndexed { i, (rect, _) ->
            translateText(texts[i], src, tgt) { t ->
                val (bg, complex) = sampleBackground(bmp, rect)
                items[i] = TranslationOverlayView.Item(rect, t, bg, contrast(bg), complex)
                if (--pending == 0) {
                    showOverlay(items.filterNotNull(), tgt in rtlCodes)
                    recognizer?.close()
                    bmp.recycle()
                }
            }
        }
    }

    // يرجّع لون متوسط الخلفية، وهل الخلفية "معقدة" (صورة/تدرج) عشان نرسمها بطريقة مختلفة
    private fun sampleBackground(bmp: Bitmap, r: Rect): Pair<Int, Boolean> {
        val pad = 6
        val xs = intArrayOf(r.left - pad, (r.left + r.right) / 2, r.right + pad)
        val ys = intArrayOf(r.top - pad, (r.top + r.bottom) / 2, r.bottom + pad)
        val samples = mutableListOf<Int>()
        for (x in xs) for (y in ys) {
            if (x == xs[1] && y == ys[1]) continue
            val sx = x.coerceIn(0, bmp.width - 1); val sy = y.coerceIn(0, bmp.height - 1)
            samples.add(bmp.getPixel(sx, sy))
        }
        var rr = 0; var g = 0; var b = 0
        for (px in samples) { rr += Color.red(px); g += Color.green(px); b += Color.blue(px) }
        val n = samples.size.coerceAtLeast(1)
        val mean = Color.rgb(rr / n, g / n, b / n)
        var maxDiff = 0
        for (px in samples) {
            val diff = Math.abs(Color.red(px) - Color.red(mean)) +
                    Math.abs(Color.green(px) - Color.green(mean)) +
                    Math.abs(Color.blue(px) - Color.blue(mean))
            if (diff > maxDiff) maxDiff = diff
        }
        return mean to (maxDiff > 90)
    }

    private fun contrast(bg: Int): Int {
        val lum = 0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)
        return if (lum > 140) Color.BLACK else Color.WHITE
    }

    // ---------- overlay ----------
    private fun showOverlay(items: List<TranslationOverlayView.Item>, rtl: Boolean) {
        val v = TranslationOverlayView(this).apply {
            this.items = items
            this.rtl = rtl
            onDismiss = { dismissOverlay() }
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28)
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        try { wm.addView(v, p) } catch (_: Exception) { busy = false; button?.visibility = View.VISIBLE; return }
        overlay = v
        // أعد الزر والشارة فوق الطبقة
        button?.let { try { wm.removeView(it) } catch (_: Exception) {}; wm.addView(it, buttonParams); it.visibility = View.VISIBLE }
        langBadge?.let { try { wm.removeView(it) } catch (_: Exception) {}; wm.addView(it, langBadgeParams) }
        busy = false
    }

    private fun dismissOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
    }

    private fun fail(msg: String) {
        button?.visibility = View.VISIBLE
        busy = false
        toast(msg)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        handler.removeCallbacks(periodicAdRunnable)
        dismissOverlay()
        hideChooser()
        hideCloseMark()
        button?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        langBadge?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        synchronized(lock) { latest?.close(); latest = null }
        vDisplay?.release(); reader?.close(); projection?.stop()
        netExecutor.shutdownNow()
        super.onDestroy()
    }
}
