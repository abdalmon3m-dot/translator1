package com.example.floatingtranslator

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        private const val CHANNEL = "translator"
    }

    // كل اللغات المدعومة. ocr=true تعني إن الكاميرا/الشاشة تقدر تقرأها كلغة مصدر
    data class Lang(val code: String, val name: String, val ocr: Boolean)
    private val ALL_LANGS = listOf(
        Lang("en", "الإنجليزية", true),
        Lang("ja", "اليابانية", true),
        Lang("ko", "الكورية", true),
        Lang("zh-CN", "الصينية", true),
        Lang("fr", "الفرنسية", true),
        Lang("de", "الألمانية", true),
        Lang("es", "الإسبانية", true),
        Lang("it", "الإيطالية", true),
        Lang("pt", "البرتغالية", true),
        Lang("tr", "التركية", true),
        Lang("id", "الإندونيسية", true),
        Lang("vi", "الفيتنامية", true),
        Lang("hi", "الهندية", true),
        Lang("ar", "العربية", false),
        Lang("ru", "الروسية", false),
        Lang("fa", "الفارسية", false),
        Lang("ur", "الأردية", false)
    )
    private fun srcLangs() = ALL_LANGS.filter { it.ocr }
    private val rtlCodes = setOf("ar", "fa", "ur", "he")

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var latest: Image? = null
    private val lock = Any()
    private var sw = 0
    private var sh = 0

    private var button: TextView? = null
    private var buttonParams: WindowManager.LayoutParams? = null
    private var overlay: TranslationOverlayView? = null
    private var chooser: View? = null
    private var busy = false

    private var currentSrc = "en"
    private var currentTgt = "ar"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (intent?.action == ACTION_START && projection == null) {
            startInForeground()
            val code = intent.getIntExtra("code", Activity.RESULT_CANCELED)
            @Suppress("DEPRECATION")
            val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
            val prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)
            currentSrc = prefs.getString("lastSrc", "en") ?: "en"
            currentTgt = prefs.getString("lastTgt", "ar") ?: "ar"
            setupCapture(code, data)
            addButton()
        }
        return START_NOT_STICKY
    }

    // ---------- foreground ----------
    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "المترجم العائم", NotificationManager.IMPORTANCE_LOW))
        }
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        val n = b.setContentTitle("المترجم العائم يعمل")
            .setContentText("اضغط الزر العائم لترجمة الشاشة")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(Notification.Action.Builder(null, "إيقاف", stop).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------- OCR ----------
    private fun buildRecognizer(src: String): TextRecognizer = when (src) {
        "ja" -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        "ko" -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        "zh-CN" -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        "hi" -> TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) // لاتيني: إنجليزي/فرنسي/ألماني/إسباني/إيطالي/برتغالي/تركي/إندونيسي/فيتنامي
    }

    // ---------- ترجمة عبر خدمة جوجل السحابية ----------
    private fun translateText(text: String, src: String, tgt: String, cb: (String) -> Unit) {
        Thread {
            val result = try {
                val q = URLEncoder.encode(text, "UTF-8")
                val urlStr = "https://translate.googleapis.com/translate_a/single" +
                        "?client=gtx&sl=$src&tl=$tgt&dt=t&q=$q"
                val conn = URL(urlStr).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                // مطلوب User-Agent وإلا خدمة جوجل بترفض الطلب بهدوء وترجع خطأ يظهر كأنه بدون ترجمة
                conn.setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0 Safari/537.36"
                )
                if (conn.responseCode != 200) throw Exception("HTTP ${conn.responseCode}")
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                parseGoogleTranslate(body)
            } catch (e: Exception) {
                null
            }
            handler.post { cb(result ?: text) }
        }.start()
    }

    private fun parseGoogleTranslate(json: String): String {
        val root = JSONArray(json)
        val segments = root.getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until segments.length()) {
            val seg = segments.getJSONArray(i)
            sb.append(seg.getString(0))
        }
        return sb.toString()
    }

    // ---------- capture ----------
    private fun setupCapture(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { handler.post { stopSelf() } }
        }, handler)

        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds; sw = b.width(); sh = b.height()
        } else {
            val m = android.util.DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m); sw = m.widthPixels; sh = m.heightPixels
        }
        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 3)
        reader!!.setOnImageAvailableListener({ r ->
            val img = try { r.acquireLatestImage() } catch (e: Exception) { null } ?: return@setOnImageAvailableListener
            synchronized(lock) { latest?.close(); latest = img }
        }, handler)
        vDisplay = projection!!.createVirtualDisplay(
            "capture", sw, sh, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler
        )
    }

    private fun grabBitmap(): Bitmap? = synchronized(lock) {
        val img = latest ?: return null
        val plane = img.planes[0]
        val rowPadding = plane.rowStride - plane.pixelStride * img.width
        val full = Bitmap.createBitmap(img.width + rowPadding / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(plane.buffer)
        val out = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
        if (out !== full) full.recycle()
        out
    }

    // ---------- الزر العائم ----------
    private fun addButton() {
        val d = resources.displayMetrics.density
        val size = (52 * d).toInt()
        val btn = TextView(this).apply {
            text = "ت"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#E61E88E5"))
            }
        }
        val p = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = sh / 3 }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        var longPressed = false
        val longPressRunnable = Runnable {
            longPressed = true
            showCloseMark()
        }
        btn.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false; longPressed = false
                    handler.postDelayed(longPressRunnable, 500)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                        moved = true
                        handler.removeCallbacks(longPressRunnable)
                    }
                    if (moved) { p.x = ox + dx; p.y = oy + dy; wm.updateViewLayout(btn, p) }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPressRunnable)
                    if (!moved && !longPressed) onButtonClick()
                }
            }
            true
        }
        button = btn; buttonParams = p
        wm.addView(btn, p)
    }

    // زر إلغاء ✕ يظهر عند الضغط المطول على الزر العائم، ويغلق التطبيق بالكامل
    private var closeMark: TextView? = null
    private fun showCloseMark() {
        if (closeMark != null) return
        val d = resources.displayMetrics.density
        val size = (56 * d).toInt()
        val mark = TextView(this).apply {
            text = "✕"; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#EF4444"))
            }
        }
        val bp = buttonParams!!
        val p = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = bp.x
            y = (bp.y - size - (10 * d)).toInt().coerceAtLeast(0)
        }
        mark.setOnClickListener {
            handler.removeCallbacksAndMessages(null)
            stopSelf()
        }
        closeMark = mark
        wm.addView(mark, p)
        toast("اضغط على ✕ لإغلاق التطبيق")
        handler.postDelayed({ hideCloseMark() }, 4000)
    }

    private fun hideCloseMark() {
        closeMark?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        closeMark = null
    }

    private fun onButtonClick() {
        if (overlay != null) { dismissOverlay(); return }
        if (busy) return
        showLanguageChooser()
    }

    // ---------- اختيار لغة المصدر والهدف ----------
    private fun langChip(lang: Lang, selectedCode: () -> String, onPick: (String) -> Unit): TextView {
        val d = resources.displayMetrics.density
        fun refreshStyle(v: TextView) {
            val isSel = selectedCode() == lang.code
            v.background = GradientDrawable().apply {
                cornerRadius = 20 * d
                setColor(if (isSel) Color.parseColor("#3B82F6") else Color.parseColor("#334155"))
            }
            v.setTextColor(if (isSel) Color.WHITE else Color.parseColor("#CBD5E1"))
        }
        return TextView(this).apply {
            text = lang.name
            textSize = 13f
            setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            refreshStyle(this)
            setOnClickListener {
                onPick(lang.code)
                (parent as? LinearLayout)?.let { row ->
                    for (i in 0 until row.childCount) refreshStyle(row.getChildAt(i) as TextView)
                }
            }
        }
    }

    private fun chipsRow(langs: List<Lang>, selectedCode: () -> String, onPick: (String) -> Unit): HorizontalScrollView {
        val d = resources.displayMetrics.density
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        langs.forEach { lang ->
            val chip = langChip(lang, selectedCode, onPick)
            row.addView(chip, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = (8 * d).toInt() })
        }
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
        }
    }

    private fun showLanguageChooser() {
        if (chooser != null) return
        val d = resources.displayMetrics.density

        var selSrc = if (srcLangs().any { it.code == currentSrc }) currentSrc else "en"
        var selTgt = currentTgt

        val dim = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#99000000"))
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = 20 * d
                setColor(Color.parseColor("#1E293B"))
            }
            setPadding((20 * d).toInt(), (20 * d).toInt(), (20 * d).toInt(), (20 * d).toInt())
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        fun label(t: String) = TextView(this).apply {
            text = t; textSize = 14f; setTextColor(Color.parseColor("#94A3B8"))
            setPadding(0, (10 * d).toInt(), 0, (6 * d).toInt())
        }

        card.addView(TextView(this).apply {
            text = "اختر لغة الترجمة"; textSize = 17f; setTextColor(Color.WHITE)
            setPadding(0, 0, 0, (4 * d).toInt())
        })

        card.addView(label("من لغة:"))
        val srcRow = chipsRow(srcLangs(), { selSrc }) { selSrc = it }
        card.addView(srcRow)

        card.addView(label("إلى لغة:"))
        val tgtRow = chipsRow(ALL_LANGS, { selTgt }) { selTgt = it }
        card.addView(tgtRow)

        val goBtn = TextView(this).apply {
            text = "ترجم الآن"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                cornerRadius = 14 * d
                setColor(Color.parseColor("#2563EB"))
            }
            setPadding(0, (14 * d).toInt(), 0, (14 * d).toInt())
            setOnClickListener {
                currentSrc = selSrc; currentTgt = selTgt
                getSharedPreferences("prefs", Context.MODE_PRIVATE).edit()
                    .putString("lastSrc", selSrc).putString("lastTgt", selTgt).apply()
                hideChooser()
                busy = true
                button?.visibility = View.INVISIBLE
                handler.postDelayed({ startTranslation(selSrc, selTgt) }, 200)
            }
        }
        card.addView(goBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = (16 * d).toInt() })

        val cancelBtn = TextView(this).apply {
            text = "إلغاء"
            textSize = 13f
            setTextColor(Color.parseColor("#94A3B8"))
            gravity = Gravity.CENTER
            setPadding(0, (12 * d).toInt(), 0, 0)
            setOnClickListener { hideChooser() }
        }
        card.addView(cancelBtn)

        dim.addView(card, FrameLayout.LayoutParams(
            (320 * d).toInt(), FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.CENTER })
        dim.setOnClickListener { hideChooser() }

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        chooser = dim
        wm.addView(dim, p)
    }

    private fun hideChooser() {
        chooser?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        chooser = null
    }

    // ---------- pipeline ----------
    private fun startTranslation(src: String, tgt: String) {
        val bmp = grabBitmap()
        if (bmp == null) { fail("تعذر التقاط الشاشة"); return }
        runOcr(bmp, src, tgt)
    }

    // فاصل نادر الحدوث في النصوص العادية عشان نقدر نفصل الترجمات بعد ما نترجمها مع بعض بالسياق الكامل
    private val SEP = "\n§§§\n"

    private fun runOcr(bmp: Bitmap, src: String, tgt: String) {
        val recognizer = buildRecognizer(src)
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { result ->
                val blocks = result.textBlocks.filter { it.boundingBox != null && it.text.isNotBlank() }
                if (blocks.isEmpty()) { fail("لم يتم العثور على نص"); recognizer.close(); return@addOnSuccessListener }

                val texts = blocks.map { it.text.replace('\n', ' ').trim() }
                val combined = texts.joinToString(SEP)

                // لو النص كله كبير جداً، الترجمة المجمّعة ممكن تفشل بسبب طول الرابط، فنترجم كل جملة لوحدها مباشرة
                if (combined.length > 1200) {
                    translateEachSeparately(blocks, texts, src, tgt, bmp, recognizer)
                    return@addOnSuccessListener
                }

                // ترجمة كل النصوص مرة واحدة مع بعض، عشان المحرك يفهم السياق العام بينها
                translateText(combined, src, tgt) { joinedResult ->
                    val parts = joinedResult.split(SEP.trim())
                        .map { it.trim().trim('\n') }
                    if (parts.size == blocks.size) {
                        finishBlocks(blocks, parts, bmp, tgt, recognizer)
                    } else {
                        // فشل الفصل (المحرك غيّر شكل الفاصل)، نترجم كل جملة لوحدها كحل احتياطي
                        translateEachSeparately(blocks, texts, src, tgt, bmp, recognizer)
                    }
                }
            }
            .addOnFailureListener { fail("فشل التعرف على النص"); recognizer.close() }
    }

    private fun finishBlocks(
        blocks: List<com.google.mlkit.vision.text.Text.TextBlock>,
        translations: List<String>,
        bmp: Bitmap, tgt: String, recognizer: TextRecognizer
    ) {
        val items = blocks.mapIndexed { i, b ->
            val rect = b.boundingBox!!
            val bg = sampleBackground(bmp, rect)
            TranslationOverlayView.Item(rect, translations[i], bg, contrast(bg))
        }
        showOverlay(items, tgt in rtlCodes)
        recognizer.close()
    }

    private fun translateEachSeparately(
        blocks: List<com.google.mlkit.vision.text.Text.TextBlock>,
        texts: List<String>, src: String, tgt: String,
        bmp: Bitmap, recognizer: TextRecognizer
    ) {
        val items = arrayOfNulls<TranslationOverlayView.Item>(blocks.size)
        var pending = blocks.size
        blocks.forEachIndexed { i, b ->
            val rect = b.boundingBox!!
            translateText(texts[i], src, tgt) { t ->
                val bg = sampleBackground(bmp, rect)
                items[i] = TranslationOverlayView.Item(rect, t, bg, contrast(bg))
                if (--pending == 0) {
                    showOverlay(items.filterNotNull(), tgt in rtlCodes)
                    recognizer.close()
                }
            }
        }
    }

    private fun sampleBackground(bmp: Bitmap, r: Rect): Int {
        val pad = 6
        val xs = intArrayOf(r.left - pad, (r.left + r.right) / 2, r.right + pad)
        val ys = intArrayOf(r.top - pad, (r.top + r.bottom) / 2, r.bottom + pad)
        var rr = 0; var g = 0; var b = 0; var n = 0
        for (x in xs) for (y in ys) {
            if (x == xs[1] && y == ys[1]) continue
            val px = bmp.getPixel(x.coerceIn(0, bmp.width - 1), y.coerceIn(0, bmp.height - 1))
            rr += Color.red(px); g += Color.green(px); b += Color.blue(px); n++
        }
        return Color.rgb(rr / n, g / n, b / n)
    }

    private fun contrast(bg: Int): Int {
        val lum = 0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)
        return if (lum > 140) Color.BLACK else Color.WHITE
    }

    // ---------- overlay ----------
    private fun showOverlay(items: List<TranslationOverlayView.Item>, rtl: Boolean) {
        val v = TranslationOverlayView(this).apply {
            this.items = items
            this.rtl = rtl
            onDismiss = { dismissOverlay() }
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28)
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        wm.addView(v, p)
        overlay = v
        // أعد الزر فوق الطبقة
        button?.let { wm.removeView(it); wm.addView(it, buttonParams); it.visibility = View.VISIBLE }
        busy = false
    }

    private fun dismissOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
    }

    private fun fail(msg: String) {
        button?.visibility = View.VISIBLE
        busy = false
        toast(msg)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        dismissOverlay()
        hideChooser()
        hideCloseMark()
        button?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        synchronized(lock) { latest?.close(); latest = null }
        vDisplay?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
}
