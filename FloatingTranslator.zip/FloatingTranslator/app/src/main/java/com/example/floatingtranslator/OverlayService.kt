package com.example.floatingtranslator

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.nl.translate.*
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        private const val CHANNEL = "translator"
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var latest: Image? = null
    private val lock = Any()
    private var sw = 0
    private var sh = 0

    private var button: TextView? = null
    private var buttonParams: WindowManager.LayoutParams? = null
    private var overlay: TranslationOverlayView? = null
    private var busy = false

    private var recognizer: TextRecognizer? = null
    private var translator: Translator? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (intent?.action == ACTION_START && projection == null) {
            startInForeground()
            val code = intent.getIntExtra("code", Activity.RESULT_CANCELED)
            @Suppress("DEPRECATION")
            val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
            setupLanguage(intent.getStringExtra("src") ?: "ja")
            setupCapture(code, data)
            addButton()
        }
        return START_NOT_STICKY
    }

    // ---------- foreground ----------
    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "المترجم العائم", NotificationManager.IMPORTANCE_LOW))
        }
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        val n = b.setContentTitle("المترجم العائم يعمل")
            .setContentText("اضغط الزر العائم لترجمة الشاشة")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(Notification.Action.Builder(null, "إيقاف", stop).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------- language / ML ----------
    private fun setupLanguage(src: String) {
        recognizer = TextRecognition.getClient(
            when (src) {
                "ja" -> JapaneseTextRecognizerOptions.Builder().build()
                "ko" -> KoreanTextRecognizerOptions.Builder().build()
                "zh" -> ChineseTextRecognizerOptions.Builder().build()
                else -> TextRecognizerOptions.DEFAULT_OPTIONS
            }
        )
        val code = when (src) {
            "ja" -> TranslateLanguage.JAPANESE
            "ko" -> TranslateLanguage.KOREAN
            "zh" -> TranslateLanguage.CHINESE
            else -> TranslateLanguage.ENGLISH
        }
        translator = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(code).setTargetLanguage(TranslateLanguage.ARABIC).build()
        )
        translator!!.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnFailureListener { toast("تعذر تنزيل نموذج الترجمة، تحقق من الإنترنت") }
    }

    // ---------- capture ----------
    private fun setupCapture(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { handler.post { stopSelf() } }
        }, handler)

        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds; sw = b.width(); sh = b.height()
        } else {
            val m = android.util.DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m); sw = m.widthPixels; sh = m.heightPixels
        }
        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 3)
        reader!!.setOnImageAvailableListener({ r ->
            val img = try { r.acquireLatestImage() } catch (e: Exception) { null } ?: return@setOnImageAvailableListener
            synchronized(lock) { latest?.close(); latest = img }
        }, handler)
        vDisplay = projection!!.createVirtualDisplay(
            "capture", sw, sh, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler
        )
    }

    private fun grabBitmap(): Bitmap? = synchronized(lock) {
        val img = latest ?: return null
        val plane = img.planes[0]
        val rowPadding = plane.rowStride - plane.pixelStride * img.width
        val full = Bitmap.createBitmap(img.width + rowPadding / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(plane.buffer)
        val out = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
        if (out !== full) full.recycle()
        out
    }

    // ---------- floating button ----------
    private fun addButton() {
        val d = resources.displayMetrics.density
        val size = (52 * d).toInt()
        val btn = TextView(this).apply {
            text = "ت"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.parseColor("#E61E88E5"))
            }
        }
        val p = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = sh / 3 }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        btn.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    if (moved) { p.x = ox + dx; p.y = oy + dy; wm.updateViewLayout(btn, p) }
                }
                MotionEvent.ACTION_UP -> if (!moved) onButtonClick()
            }
            true
        }
        button = btn; buttonParams = p
        wm.addView(btn, p)
    }

    private fun onButtonClick() {
        if (overlay != null) { dismissOverlay(); return }
        if (busy) return
        busy = true
        button?.visibility = View.INVISIBLE
        handler.postDelayed({ startTranslation() }, 250)
    }

    // ---------- pipeline ----------
    private fun startTranslation() {
        val bmp = grabBitmap()
        if (bmp == null) { fail("تعذر التقاط الشاشة"); return }
        translator!!.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { runOcr(bmp) }
            .addOnFailureListener { fail("نموذج الترجمة غير متوفر، اتصل بالإنترنت") }
    }

    private fun runOcr(bmp: Bitmap) {
        recognizer!!.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { result ->
                val blocks = result.textBlocks.filter { it.boundingBox != null && it.text.isNotBlank() }
                if (blocks.isEmpty()) { fail("لم يتم العثور على نص"); return@addOnSuccessListener }
                val items = arrayOfNulls<TranslationOverlayView.Item>(blocks.size)
                var pending = blocks.size
                blocks.forEachIndexed { i, b ->
                    val rect = b.boundingBox!!
                    translator!!.translate(b.text.replace('\n', ' '))
                        .addOnSuccessListener { t ->
                            val bg = sampleBackground(bmp, rect)
                            items[i] = TranslationOverlayView.Item(rect, t, bg, contrast(bg))
                        }
                        .addOnCompleteListener {
                            if (--pending == 0) showOverlay(items.filterNotNull())
                        }
                }
            }
            .addOnFailureListener { fail("فشل التعرف على النص") }
    }

    private fun sampleBackground(bmp: Bitmap, r: Rect): Int {
        val pad = 6
        val xs = intArrayOf(r.left - pad, (r.left + r.right) / 2, r.right + pad)
        val ys = intArrayOf(r.top - pad, (r.top + r.bottom) / 2, r.bottom + pad)
        var rr = 0; var g = 0; var b = 0; var n = 0
        for (x in xs) for (y in ys) {
            if (x == xs[1] && y == ys[1]) continue
            val px = bmp.getPixel(x.coerceIn(0, bmp.width - 1), y.coerceIn(0, bmp.height - 1))
            rr += Color.red(px); g += Color.green(px); b += Color.blue(px); n++
        }
        return Color.rgb(rr / n, g / n, b / n)
    }

    private fun contrast(bg: Int): Int {
        val lum = 0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)
        return if (lum > 140) Color.BLACK else Color.WHITE
    }

    // ---------- overlay ----------
    private fun showOverlay(items: List<TranslationOverlayView.Item>) {
        val v = TranslationOverlayView(this).apply {
            this.items = items
            onDismiss = { dismissOverlay() }
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28)
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        wm.addView(v, p)
        overlay = v
        // أعد الزر فوق الطبقة
        button?.let { wm.removeView(it); wm.addView(it, buttonParams); it.visibility = View.VISIBLE }
        busy = false
    }

    private fun dismissOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
    }

    private fun fail(msg: String) {
        button?.visibility = View.VISIBLE
        busy = false
        toast(msg)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        dismissOverlay()
        button?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        synchronized(lock) { latest?.close(); latest = null }
        vDisplay?.release(); reader?.close(); projection?.stop()
        recognizer?.close(); translator?.close()
        super.onDestroy()
    }
}
