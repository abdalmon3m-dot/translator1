package com.example.floatingtranslator

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.io.FileOutputStream

// Google ML Kit مش بيدعم قراءة الخط العربي من الشاشة، فبنستخدم Tesseract بس للعربي.
// بيرجّع قائمة بأسطر النص مع مواقعها، بنفس شكل بيانات ML Kit، عشان نقدر نستخدم نفس نظام
// التجميع البصري (buildVisualBlocks) لكل المحركين من غير أي فرق في باقي الكود.
object TesseractOcr {
    private const val LANG = "ara"

    private fun ensureData(context: Context): File {
        val root = File(context.filesDir, "tesseract")
        val tessDir = File(root, "tessdata")
        if (!tessDir.exists()) tessDir.mkdirs()
        val dataFile = File(tessDir, "$LANG.traineddata")
        if (!dataFile.exists()) {
            context.assets.open("tessdata/$LANG.traineddata").use { input ->
                FileOutputStream(dataFile).use { output -> input.copyTo(output) }
            }
        }
        return root
    }

    // هذه الدالة بطيئة (Tesseract متزامن)، لازم تتنفذ في Thread خلفي
    fun extractLines(context: Context, bmp: Bitmap): List<OcrLine> {
        val dataRoot = try { ensureData(context) } catch (e: Exception) { return emptyList() }
        val tess = TessBaseAPI()
        return try {
            if (!tess.init(dataRoot.absolutePath, LANG)) return emptyList()
            tess.setImage(bmp)
            tess.utF8Text // تشغيل التعرف على النص فعلياً
            val hocr = tess.getHOCRText(0) ?: return emptyList()
            groupWordsIntoLines(parseHocrWords(hocr))
        } catch (e: Exception) {
            emptyList()
        } finally {
            try { tess.recycle() } catch (_: Exception) {}
        }
    }

    // نستخرج على مستوى الكلمة (مش السطر) عشان الوسوم متداخلة في hOCR وسهل نغلط في فصلها على مستوى السطر
    private fun parseHocrWords(hocr: String): List<OcrLine> {
        val words = mutableListOf<OcrLine>()
        val wordRegex = Regex(
            "class='ocrx_word'[^>]*title='bbox (\\d+) (\\d+) (\\d+) (\\d+)[^']*'[^>]*>([^<]*)</span>"
        )
        for (m in wordRegex.findAll(hocr)) {
            val (l, t, r, b, raw) = m.destructured
            val text = raw.replace("&amp;", "&").replace("&lt;", "<")
                .replace("&gt;", ">").replace("&quot;", "\"").trim()
            if (text.isNotEmpty()) {
                words.add(OcrLine(Rect(l.toInt(), t.toInt(), r.toInt(), b.toInt()), text))
            }
        }
        return words
    }

    // نجمع الكلمات المتجاورة رأسياً في نفس السطر، ونرتبها من اليمين لليسار (اتجاه العربي الصحيح)
    private fun groupWordsIntoLines(words: List<OcrLine>): List<OcrLine> {
        if (words.isEmpty()) return emptyList()
        data class LineAcc(var rect: Rect, val items: MutableList<OcrLine>)
        val lines = mutableListOf<LineAcc>()
        for (w in words.sortedBy { it.rect.top }) {
            val cy = (w.rect.top + w.rect.bottom) / 2
            val match = lines.firstOrNull { line ->
                val lcy = (line.rect.top + line.rect.bottom) / 2
                val avgH = ((line.rect.height() + w.rect.height()) / 2).coerceAtLeast(1)
                Math.abs(cy - lcy) < avgH * 0.6
            }
            if (match != null) {
                match.items.add(w)
                match.rect.union(w.rect)
            } else {
                lines.add(LineAcc(Rect(w.rect), mutableListOf(w)))
            }
        }
        return lines.map { line ->
            val ordered = line.items.sortedByDescending { it.rect.left } // يمين لشمال
            OcrLine(line.rect, ordered.joinToString(" ") { it.text })
        }
    }
}

// تمثيل موحّد لسطر نص مكتشف، بغض النظر عن محرك القراءة (ML Kit أو Tesseract)
data class OcrLine(val rect: Rect, val text: String)
