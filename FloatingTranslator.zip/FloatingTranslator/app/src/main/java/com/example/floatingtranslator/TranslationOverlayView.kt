package com.example.floatingtranslator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.MotionEvent
import android.view.View

class TranslationOverlayView(context: Context) : View(context) {

    // translucent=true معناها إن الخلفية الأصلية معقدة (صورة/تدرج لون)، فبنرسم لوحة شبه شفافة
    // بدل مستطيل صلب كامل، عشان الترجمة تبان مندمجة أكتر ومش "لزقة" واضحة فوق الصورة
    data class Item(val rect: Rect, val text: String, val bg: Int, val fg: Int, val translucent: Boolean = false)

    var items: List<Item> = emptyList()
    var rtl: Boolean = true
    var onDismiss: (() -> Unit)? = null

    private val fill = Paint().apply { style = Paint.Style.FILL; isAntiAlias = true }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density

    override fun onDraw(canvas: Canvas) {
        for (it in items) {
            val r = Rect(it.rect).apply { inset((-4 * d).toInt(), (-2 * d).toInt()) }
            fill.color = it.bg
            fill.alpha = if (it.translucent) 215 else 255
            val radius = 6 * d
            canvas.drawRoundRect(RectF(r), radius, radius, fill)

            tp.color = it.fg
            val w = r.width().coerceAtLeast(1)
            var size = r.height().toFloat().coerceAtMost(42 * d)
            val minSize = 9 * d
            var layout = build(it.text, w, size)
            while (layout.height > r.height() && size > minSize) {
                size -= 1.5f * d
                layout = build(it.text, w, size)
            }
            canvas.save()
            canvas.translate(r.left.toFloat(), r.top + (r.height() - layout.height).coerceAtLeast(0) / 2f)
            layout.draw(canvas)
            canvas.restore()
        }
    }

    private fun build(text: String, width: Int, size: Float): StaticLayout {
        tp.textSize = size
        return StaticLayout.Builder.obtain(text, 0, text.length, tp, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setTextDirection(if (rtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.LTR)
            .setIncludePad(false)
            .build()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) { onDismiss?.invoke() }
        return true
    }
}
